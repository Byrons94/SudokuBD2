﻿namespace Sudoku
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Orange;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(67, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "Cargar tabla";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(269, 27);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox1.Location = new System.Drawing.Point(67, 110);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(44, 38);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox2.Location = new System.Drawing.Point(117, 110);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(44, 38);
            this.textBox2.TabIndex = 4;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox3.Location = new System.Drawing.Point(167, 110);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(44, 38);
            this.textBox3.TabIndex = 5;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox4.Location = new System.Drawing.Point(246, 110);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(44, 38);
            this.textBox4.TabIndex = 6;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox5.Location = new System.Drawing.Point(296, 110);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(44, 38);
            this.textBox5.TabIndex = 7;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox6.Location = new System.Drawing.Point(346, 110);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(44, 38);
            this.textBox6.TabIndex = 8;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox7.Location = new System.Drawing.Point(425, 110);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(44, 38);
            this.textBox7.TabIndex = 9;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox8.Location = new System.Drawing.Point(475, 110);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(44, 38);
            this.textBox8.TabIndex = 10;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox9.Location = new System.Drawing.Point(525, 110);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(44, 38);
            this.textBox9.TabIndex = 11;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox10.Location = new System.Drawing.Point(67, 154);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(44, 38);
            this.textBox10.TabIndex = 12;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox11.Location = new System.Drawing.Point(117, 154);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(44, 38);
            this.textBox11.TabIndex = 13;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox12.Location = new System.Drawing.Point(167, 154);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(44, 38);
            this.textBox12.TabIndex = 14;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox13.Location = new System.Drawing.Point(246, 154);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(44, 38);
            this.textBox13.TabIndex = 15;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox14.Location = new System.Drawing.Point(296, 154);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(44, 38);
            this.textBox14.TabIndex = 16;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox15.Location = new System.Drawing.Point(346, 154);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(44, 38);
            this.textBox15.TabIndex = 17;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox16.Location = new System.Drawing.Point(425, 154);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(44, 38);
            this.textBox16.TabIndex = 18;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox17.Location = new System.Drawing.Point(475, 154);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(44, 38);
            this.textBox17.TabIndex = 19;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox18.Location = new System.Drawing.Point(525, 154);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(44, 38);
            this.textBox18.TabIndex = 20;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox19.Location = new System.Drawing.Point(67, 198);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(44, 38);
            this.textBox19.TabIndex = 21;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox20.Location = new System.Drawing.Point(117, 198);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(44, 38);
            this.textBox20.TabIndex = 22;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox21.Location = new System.Drawing.Point(167, 198);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(44, 38);
            this.textBox21.TabIndex = 23;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox22.Location = new System.Drawing.Point(246, 198);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(44, 38);
            this.textBox22.TabIndex = 24;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox23.Location = new System.Drawing.Point(296, 198);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(44, 38);
            this.textBox23.TabIndex = 25;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox24.Location = new System.Drawing.Point(346, 198);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(44, 38);
            this.textBox24.TabIndex = 26;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox25.Location = new System.Drawing.Point(425, 198);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(44, 38);
            this.textBox25.TabIndex = 27;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox26.Location = new System.Drawing.Point(475, 198);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(44, 38);
            this.textBox26.TabIndex = 28;
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox27.Location = new System.Drawing.Point(525, 198);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(44, 38);
            this.textBox27.TabIndex = 29;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox28.Location = new System.Drawing.Point(67, 266);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(44, 38);
            this.textBox28.TabIndex = 30;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox29.Location = new System.Drawing.Point(117, 266);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(44, 38);
            this.textBox29.TabIndex = 31;
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox30.Location = new System.Drawing.Point(167, 266);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(44, 38);
            this.textBox30.TabIndex = 32;
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox31.Location = new System.Drawing.Point(246, 266);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(44, 38);
            this.textBox31.TabIndex = 33;
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox32.Location = new System.Drawing.Point(296, 266);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(44, 38);
            this.textBox32.TabIndex = 34;
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox33.Location = new System.Drawing.Point(346, 266);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(44, 38);
            this.textBox33.TabIndex = 35;
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox34.Location = new System.Drawing.Point(425, 266);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(44, 38);
            this.textBox34.TabIndex = 36;
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox35.Location = new System.Drawing.Point(475, 266);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(44, 38);
            this.textBox35.TabIndex = 37;
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox36.Location = new System.Drawing.Point(525, 266);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(44, 38);
            this.textBox36.TabIndex = 38;
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox37.Location = new System.Drawing.Point(67, 310);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(44, 38);
            this.textBox37.TabIndex = 39;
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox38.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox38.Location = new System.Drawing.Point(117, 310);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(44, 38);
            this.textBox38.TabIndex = 40;
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox39.Location = new System.Drawing.Point(167, 310);
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.Size = new System.Drawing.Size(44, 38);
            this.textBox39.TabIndex = 41;
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox40.Location = new System.Drawing.Point(246, 310);
            this.textBox40.Name = "textBox40";
            this.textBox40.ReadOnly = true;
            this.textBox40.Size = new System.Drawing.Size(44, 38);
            this.textBox40.TabIndex = 42;
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox41.Location = new System.Drawing.Point(296, 310);
            this.textBox41.Name = "textBox41";
            this.textBox41.ReadOnly = true;
            this.textBox41.Size = new System.Drawing.Size(44, 38);
            this.textBox41.TabIndex = 43;
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox42.Location = new System.Drawing.Point(346, 310);
            this.textBox42.Name = "textBox42";
            this.textBox42.ReadOnly = true;
            this.textBox42.Size = new System.Drawing.Size(44, 38);
            this.textBox42.TabIndex = 44;
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox43.Location = new System.Drawing.Point(425, 310);
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.Size = new System.Drawing.Size(44, 38);
            this.textBox43.TabIndex = 45;
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox44.Location = new System.Drawing.Point(475, 310);
            this.textBox44.Name = "textBox44";
            this.textBox44.ReadOnly = true;
            this.textBox44.Size = new System.Drawing.Size(44, 38);
            this.textBox44.TabIndex = 46;
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox45.Location = new System.Drawing.Point(525, 310);
            this.textBox45.Name = "textBox45";
            this.textBox45.ReadOnly = true;
            this.textBox45.Size = new System.Drawing.Size(44, 38);
            this.textBox45.TabIndex = 47;
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox46.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox46.Location = new System.Drawing.Point(67, 354);
            this.textBox46.Name = "textBox46";
            this.textBox46.ReadOnly = true;
            this.textBox46.Size = new System.Drawing.Size(44, 38);
            this.textBox46.TabIndex = 48;
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox47.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox47.Location = new System.Drawing.Point(117, 354);
            this.textBox47.Name = "textBox47";
            this.textBox47.ReadOnly = true;
            this.textBox47.Size = new System.Drawing.Size(44, 38);
            this.textBox47.TabIndex = 49;
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox48.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox48.Location = new System.Drawing.Point(167, 354);
            this.textBox48.Name = "textBox48";
            this.textBox48.ReadOnly = true;
            this.textBox48.Size = new System.Drawing.Size(44, 38);
            this.textBox48.TabIndex = 50;
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox49
            // 
            this.textBox49.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox49.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox49.Location = new System.Drawing.Point(246, 354);
            this.textBox49.Name = "textBox49";
            this.textBox49.ReadOnly = true;
            this.textBox49.Size = new System.Drawing.Size(44, 38);
            this.textBox49.TabIndex = 51;
            this.textBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox50
            // 
            this.textBox50.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox50.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox50.Location = new System.Drawing.Point(296, 354);
            this.textBox50.Name = "textBox50";
            this.textBox50.ReadOnly = true;
            this.textBox50.Size = new System.Drawing.Size(44, 38);
            this.textBox50.TabIndex = 52;
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox51.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox51.Location = new System.Drawing.Point(346, 354);
            this.textBox51.Name = "textBox51";
            this.textBox51.ReadOnly = true;
            this.textBox51.Size = new System.Drawing.Size(44, 38);
            this.textBox51.TabIndex = 53;
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox52
            // 
            this.textBox52.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox52.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox52.Location = new System.Drawing.Point(425, 354);
            this.textBox52.Name = "textBox52";
            this.textBox52.ReadOnly = true;
            this.textBox52.Size = new System.Drawing.Size(44, 38);
            this.textBox52.TabIndex = 54;
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox53.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox53.Location = new System.Drawing.Point(475, 354);
            this.textBox53.Name = "textBox53";
            this.textBox53.ReadOnly = true;
            this.textBox53.Size = new System.Drawing.Size(44, 38);
            this.textBox53.TabIndex = 55;
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox54
            // 
            this.textBox54.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox54.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox54.Location = new System.Drawing.Point(525, 354);
            this.textBox54.Name = "textBox54";
            this.textBox54.ReadOnly = true;
            this.textBox54.Size = new System.Drawing.Size(44, 38);
            this.textBox54.TabIndex = 56;
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox55.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox55.Location = new System.Drawing.Point(67, 419);
            this.textBox55.Name = "textBox55";
            this.textBox55.ReadOnly = true;
            this.textBox55.Size = new System.Drawing.Size(44, 38);
            this.textBox55.TabIndex = 57;
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            this.textBox56.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox56.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox56.Location = new System.Drawing.Point(117, 419);
            this.textBox56.Name = "textBox56";
            this.textBox56.ReadOnly = true;
            this.textBox56.Size = new System.Drawing.Size(44, 38);
            this.textBox56.TabIndex = 58;
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            this.textBox57.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox57.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox57.Location = new System.Drawing.Point(167, 419);
            this.textBox57.Name = "textBox57";
            this.textBox57.ReadOnly = true;
            this.textBox57.Size = new System.Drawing.Size(44, 38);
            this.textBox57.TabIndex = 59;
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox58
            // 
            this.textBox58.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox58.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox58.Location = new System.Drawing.Point(246, 419);
            this.textBox58.Name = "textBox58";
            this.textBox58.ReadOnly = true;
            this.textBox58.Size = new System.Drawing.Size(44, 38);
            this.textBox58.TabIndex = 60;
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox59
            // 
            this.textBox59.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox59.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox59.Location = new System.Drawing.Point(296, 419);
            this.textBox59.Name = "textBox59";
            this.textBox59.ReadOnly = true;
            this.textBox59.Size = new System.Drawing.Size(44, 38);
            this.textBox59.TabIndex = 61;
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox60
            // 
            this.textBox60.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox60.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox60.Location = new System.Drawing.Point(346, 419);
            this.textBox60.Name = "textBox60";
            this.textBox60.ReadOnly = true;
            this.textBox60.Size = new System.Drawing.Size(44, 38);
            this.textBox60.TabIndex = 62;
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox61
            // 
            this.textBox61.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox61.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox61.Location = new System.Drawing.Point(425, 419);
            this.textBox61.Name = "textBox61";
            this.textBox61.ReadOnly = true;
            this.textBox61.Size = new System.Drawing.Size(44, 38);
            this.textBox61.TabIndex = 63;
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox62
            // 
            this.textBox62.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox62.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox62.Location = new System.Drawing.Point(475, 419);
            this.textBox62.Name = "textBox62";
            this.textBox62.ReadOnly = true;
            this.textBox62.Size = new System.Drawing.Size(44, 38);
            this.textBox62.TabIndex = 64;
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            this.textBox63.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox63.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox63.Location = new System.Drawing.Point(525, 419);
            this.textBox63.Name = "textBox63";
            this.textBox63.ReadOnly = true;
            this.textBox63.Size = new System.Drawing.Size(44, 38);
            this.textBox63.TabIndex = 65;
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64
            // 
            this.textBox64.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox64.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox64.Location = new System.Drawing.Point(67, 463);
            this.textBox64.Name = "textBox64";
            this.textBox64.ReadOnly = true;
            this.textBox64.Size = new System.Drawing.Size(44, 38);
            this.textBox64.TabIndex = 66;
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65
            // 
            this.textBox65.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox65.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox65.Location = new System.Drawing.Point(117, 463);
            this.textBox65.Name = "textBox65";
            this.textBox65.ReadOnly = true;
            this.textBox65.Size = new System.Drawing.Size(44, 38);
            this.textBox65.TabIndex = 67;
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox66
            // 
            this.textBox66.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox66.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox66.Location = new System.Drawing.Point(167, 463);
            this.textBox66.Name = "textBox66";
            this.textBox66.ReadOnly = true;
            this.textBox66.Size = new System.Drawing.Size(44, 38);
            this.textBox66.TabIndex = 68;
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox67
            // 
            this.textBox67.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox67.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox67.Location = new System.Drawing.Point(246, 463);
            this.textBox67.Name = "textBox67";
            this.textBox67.ReadOnly = true;
            this.textBox67.Size = new System.Drawing.Size(44, 38);
            this.textBox67.TabIndex = 69;
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox68
            // 
            this.textBox68.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox68.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox68.Location = new System.Drawing.Point(296, 463);
            this.textBox68.Name = "textBox68";
            this.textBox68.ReadOnly = true;
            this.textBox68.Size = new System.Drawing.Size(44, 38);
            this.textBox68.TabIndex = 70;
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox69
            // 
            this.textBox69.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox69.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox69.Location = new System.Drawing.Point(346, 463);
            this.textBox69.Name = "textBox69";
            this.textBox69.ReadOnly = true;
            this.textBox69.Size = new System.Drawing.Size(44, 38);
            this.textBox69.TabIndex = 71;
            this.textBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox70
            // 
            this.textBox70.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox70.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox70.Location = new System.Drawing.Point(425, 463);
            this.textBox70.Name = "textBox70";
            this.textBox70.ReadOnly = true;
            this.textBox70.Size = new System.Drawing.Size(44, 38);
            this.textBox70.TabIndex = 72;
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox71
            // 
            this.textBox71.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox71.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox71.Location = new System.Drawing.Point(475, 463);
            this.textBox71.Name = "textBox71";
            this.textBox71.ReadOnly = true;
            this.textBox71.Size = new System.Drawing.Size(44, 38);
            this.textBox71.TabIndex = 73;
            this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox72
            // 
            this.textBox72.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox72.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox72.Location = new System.Drawing.Point(525, 463);
            this.textBox72.Name = "textBox72";
            this.textBox72.ReadOnly = true;
            this.textBox72.Size = new System.Drawing.Size(44, 38);
            this.textBox72.TabIndex = 74;
            this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox73
            // 
            this.textBox73.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox73.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox73.Location = new System.Drawing.Point(67, 507);
            this.textBox73.Name = "textBox73";
            this.textBox73.ReadOnly = true;
            this.textBox73.Size = new System.Drawing.Size(44, 38);
            this.textBox73.TabIndex = 75;
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox74
            // 
            this.textBox74.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox74.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox74.Location = new System.Drawing.Point(117, 507);
            this.textBox74.Name = "textBox74";
            this.textBox74.ReadOnly = true;
            this.textBox74.Size = new System.Drawing.Size(44, 38);
            this.textBox74.TabIndex = 76;
            this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox75
            // 
            this.textBox75.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox75.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox75.Location = new System.Drawing.Point(167, 507);
            this.textBox75.Name = "textBox75";
            this.textBox75.ReadOnly = true;
            this.textBox75.Size = new System.Drawing.Size(44, 38);
            this.textBox75.TabIndex = 77;
            this.textBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox76
            // 
            this.textBox76.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox76.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox76.Location = new System.Drawing.Point(246, 507);
            this.textBox76.Name = "textBox76";
            this.textBox76.ReadOnly = true;
            this.textBox76.Size = new System.Drawing.Size(44, 38);
            this.textBox76.TabIndex = 78;
            this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox77
            // 
            this.textBox77.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox77.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox77.Location = new System.Drawing.Point(296, 507);
            this.textBox77.Name = "textBox77";
            this.textBox77.ReadOnly = true;
            this.textBox77.Size = new System.Drawing.Size(44, 38);
            this.textBox77.TabIndex = 79;
            this.textBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox78
            // 
            this.textBox78.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox78.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox78.Location = new System.Drawing.Point(346, 507);
            this.textBox78.Name = "textBox78";
            this.textBox78.ReadOnly = true;
            this.textBox78.Size = new System.Drawing.Size(44, 38);
            this.textBox78.TabIndex = 80;
            this.textBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox79
            // 
            this.textBox79.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox79.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox79.Location = new System.Drawing.Point(425, 507);
            this.textBox79.Name = "textBox79";
            this.textBox79.ReadOnly = true;
            this.textBox79.Size = new System.Drawing.Size(44, 38);
            this.textBox79.TabIndex = 81;
            this.textBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox80
            // 
            this.textBox80.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox80.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox80.Location = new System.Drawing.Point(475, 507);
            this.textBox80.Name = "textBox80";
            this.textBox80.ReadOnly = true;
            this.textBox80.Size = new System.Drawing.Size(44, 38);
            this.textBox80.TabIndex = 82;
            this.textBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox81
            // 
            this.textBox81.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox81.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox81.Location = new System.Drawing.Point(525, 507);
            this.textBox81.Name = "textBox81";
            this.textBox81.ReadOnly = true;
            this.textBox81.Size = new System.Drawing.Size(44, 38);
            this.textBox81.TabIndex = 83;
            this.textBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(475, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 34);
            this.button2.TabIndex = 84;
            this.button2.Text = "Resolver";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(166, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 85;
            this.label1.Text = "Partida";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(654, 579);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
    }
}

