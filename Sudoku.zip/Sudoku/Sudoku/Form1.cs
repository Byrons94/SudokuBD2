﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections;
using Oracle.DataAccess;
using System.Configuration;
using System.Data.OracleClient;


namespace Sudoku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1_Cargar();
        }

        OleDbConnection con = new OleDbConnection("Provider=MSDAORA;Data Source=XE;User ID=system;Password=oracle;Unicode=True");
        
       

        private void comboBox1_Cargar()
        {
            con.Open();


          
            OleDbDataAdapter oda5 = new OleDbDataAdapter("select nivel from plantillas", con);
            DataTable dt = new DataTable();
            oda5.Fill(dt);



            foreach (DataRow row in dt.Rows)
            {

                comboBox1.Items.Add(row["nivel"]);
            }

            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            crearPlantillas(Convert.ToInt16( comboBox1.SelectedItem.ToString()),1);
            cargar();
            
        }

    


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cargar()
        {

            //comboBox1.Items.Clear();
           // comboBox1_Cargar();

            String combo = comboBox1.SelectedItem.ToString();
            con.Open();


            OleDbDataAdapter oda1 = new OleDbDataAdapter("SELECT  tpos.id, tpis.valor VAL FROM partidas tpar INNER JOIN plantillas tplan ON tplan.id = tpar.idPlantilla INNER JOIN pistas tpis ON tpis.idPlantilla = tplan.id INNER JOIN posiciones tpos ON tpos.id = tpis.idPosicion WHERE tpar.id = '" +combo+ "' UNION SELECT tpos.id, tinc.valor VAL FROM incognitas tinc INNER JOIN posiciones tpos ON tpos.id = tinc.idPosicion WHERE tinc.idpartida = '" +combo+ "'", con);
            DataTable dt1 = new DataTable();
            oda1.Fill(dt1);

            ArrayList vals = new ArrayList();

            foreach (DataRow row in dt1.Rows)
            {

                vals.Add(row["VAL"]);
            }


            if (vals.Count != 0)
            {

                int i = 80;

                foreach (Control X in this.Controls)
                {
                    if (X is TextBox)
                    {
                        (X as TextBox).Text = vals[i].ToString();
                        i--;
                    }

                }

            }
           

            

            //vals.Clear();

            con.Close();
            
        }

    
        private void button2_Click_1(object sender, EventArgs e)
        {
            //con.Open();
            //OleDbDataAdapter oda = new OleDbDataAdapter("execute resolverjuego('" + comboBox1.SelectedItem.ToString() + "')", con);

            //OleDbDataAdapter oda2 = new OleDbDataAdapter("commit",con);

            string str = "Data Source=XE;User ID=system;Password=oracle;Unicode=True";
            OracleConnection conn = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("ResolverJuego", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("pidPartida", "integer").Value = Convert.ToInt32(comboBox1.SelectedItem.ToString());

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cargar();
            
        }

        private void crearPlantillas(int pla, int usr)
        {
            //con.Open();
            //OleDbDataAdapter oda = new OleDbDataAdapter("delete  from probabilidades", con);
            //OleDbDataAdapter oda2 = new OleDbDataAdapter("delete  from incognitas", con);
            //OleDbDataAdapter oda3 = new OleDbDataAdapter("delete  from partidas", con);
            //OleDbDataAdapter oda4 = new OleDbDataAdapter("commit", con);
            //con.Close();

            borrar("probabilidades");
            borrar("incognitas");
            borrar("partidas");


            string str = "Data Source=XE;User ID=system;Password=oracle;Unicode=True";
            OracleConnection conn = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("CrearPartida", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("pidPlantilla", "integer").Value = pla;
            cmd.Parameters.Add("pidUsuario", "integer").Value = usr;

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void borrar(String tab)
        {
            string str = "Data Source=XE;User ID=system;Password=oracle;Unicode=True";
            OracleConnection conn = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("delete  from "+tab, conn);
            cmd.CommandType = CommandType.Text;

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

        }

       
    }
}
